import requests
import json

url = ("https://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json")

params = {"key": "549a3a8dbe2cb6a2abf7af714b841164", "targetDt": "20260824"}

response = requests.get(url, params=params, timeout=10)

data = response.json()
result = data['boxOfficeResult']

movies = result['dailyBoxOfficeList']
'''first = movies[0]
print(first['rank'])
print(first['movieNm'])
print(first['audiCnt'])'''

for movie in movies[:5]:
    rank = movie['rank']
    name = movie['movieNm']
    audi = int(movie['audiCnt'])
    print(f"{rank}위: {name} - 관객수: {audi}")

