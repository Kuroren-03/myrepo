import os

API_KEY = os.getenv("KOBIS_API_KEY")
